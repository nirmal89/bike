import { Component } from '@angular/core';  
@Component({
  selector: 'home-app',
  templateUrl: './gallery.html',  
})
export class GalleryComponent{ 
 
}
