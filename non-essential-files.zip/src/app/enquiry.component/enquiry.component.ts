import { Component } from '@angular/core';  
@Component({
  selector: 'enquiry-app',
  templateUrl: './enquiry.html'
  
})
export class EnquiryComponent  {
    onClick(){
        
    }
 }
