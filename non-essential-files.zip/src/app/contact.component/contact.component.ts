import { Component } from '@angular/core';  
@Component({
  selector: 'contact-app',
  templateUrl: './contact.html'
  
})
export class ContactComponent  { }
